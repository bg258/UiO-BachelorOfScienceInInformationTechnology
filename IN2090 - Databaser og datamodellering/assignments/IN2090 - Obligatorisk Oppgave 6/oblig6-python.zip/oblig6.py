import psycopg2
import getpass
import sys
from timelistedb import TimelisteDb

if __name__ == "__main__":
    if sys.version_info[0] < 3:
        print("OBS: Obligen skal loses med Python 3!")
        print("Kanskje det allerede er installert? Prov 'python3 oblig6.py'")
        sys.exit(1)
    
    conn = psycopg2.connect(
        host="dbpg-ifi-kurs.uio.no",
        dbname="dittBrukernavn", # sett inn ditt brukernavn her
        user="dittBrukernavn", # sett inn ditt brukernavn her
        password=getpass.getpass("Passord: "),
        sslmode='require')

    db = TimelisteDb(conn)

    print("Alle timelister:")
    db.print_timelister()

    print("\nVelg en timeliste:")
    timelistenr = int(input("Timelistenr: "))
    db.print_timelistelinjer(timelistenr)

    print("Median-timeantall for timeliste {}: ".format(timelistenr))
    median_timeantall = db.median_timeantall(timelistenr)
    print(median_timeantall)

    print("\nSett inn timelistelinje [trykk enter uten verdi for aa hoppe over innsetting]:")
    try:
        antall_timer = int(input("Antall timer: "))
        beskrivelse = input("Beskrivelse: ")
        db.sett_inn_timelistelinje(timelistenr, antall_timer, beskrivelse)
    except ValueError:
        print("Hopper over innsetting av ny timeliste...")
    
    db.regn_ut_kumulativt_timeantall(timelistenr)

    print("\nTimelistelinjer med oppdatert kumulativt timeantall:")
    db.print_timelistelinjer(timelistenr)
