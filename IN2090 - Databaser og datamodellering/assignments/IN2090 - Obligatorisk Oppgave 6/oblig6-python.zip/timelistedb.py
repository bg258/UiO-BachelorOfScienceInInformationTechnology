from statistics import median

class TimelisteDb:
    def __init__(self, conn):
        self._conn = conn

    def print_timelister(self):
        return # return kan fjernes etter at metoden er skrevet

    def print_timelistelinjer(self, timelistenr):
        return # return kan fjernes etter at metoden er skrevet

    def median_timeantall(self, timelistenr):
        return 0 # returner medianverdien i stedet for 0

    def sett_inn_timelistelinje(self, timelistenr, antall_timer, beskrivelse):
        return # return kan fjernes etter at metoden er skrevet

    def regn_ut_kumulativt_timeantall(self, timelistenr):
        return # return kan fjernes etter at metoden er skrevet
